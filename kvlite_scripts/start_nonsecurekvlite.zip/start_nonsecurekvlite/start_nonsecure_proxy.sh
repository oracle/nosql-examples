#!/bin/bash
#
# Copyright (c) 2022 Oracle and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl/
java -jar lib/httpproxy.jar -helperHosts "${HOSTNAME:-localhost}:${KV_PORT:-5000}" -storeName kvstore -httpPort "${KV_PROXY_PORT:-8080}" -verbose true &
