#!/bin/bash
#
# Copyright (c) 2022 Oracle and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl/
java -jar lib/httpproxy.jar -helperHosts "$HOSTNAME:$KV_PORT" -storeName kvstore -httpsPort "$KV_PROXY_PORT" -storeSecurityFile kvroot/proxy/proxy.login\
 -sslCertificate kvroot/proxy/certificate.pem -sslPrivateKey kvroot/proxy/key-pkcs8.pem -sslPrivateKeyPass "$(cat < <(cat kvroot/proxy/pwdin))" -verbose true &
