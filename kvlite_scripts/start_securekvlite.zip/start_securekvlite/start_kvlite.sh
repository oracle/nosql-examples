#!/bin/bash
#
# Copyright (c) 2024 Oracle and/or its affiliates.
# Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl/
ROOT="kvroot"
RESTORE_OPT=""
if [ -n "${RESTORE_SNAPSHOT:-}" ] && [ -d "${ROOT}/snapshots/${RESTORE_SNAPSHOT}" ]; then
  RESTORE_OPT="-restore-from-snapshot ${RESTORE_SNAPSHOT}"
else
  echo ""
fi
java -jar lib/kvstore.jar kvlite -secure-config enable -root kvroot -host "${HOSTNAME:-localhost}" -port "${KV_PORT:-5000}" -admin-web-port "${KV_ADMIN_WEB_PORT:--1}" -storagedirsizegb "${KV_STORAGESIZE:-10}" $RESTORE_OPT &
while ! java -jar lib/kvstore.jar ping -host "${HOSTNAME:-localhost}" -port "${KV_PORT:-5000}" -security kvroot/security/user.security  >/dev/null 2>&1 ;do
    echo "Waiting for kvstore to start..."
    sleep 1
done
