# video-on-demand-with-nosql-database
Demo Video On Demand streaming application using GraphQL and NoSQL

