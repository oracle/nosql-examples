SELECT * 
FROM demo d 
WHERE d.bagInfo.flightLegs.flightNo =ANY 'BM715'
