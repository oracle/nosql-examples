CREATE TABLE IF NOT EXISTS ProductData (
    sku String,                               
    parent_sku String,                                                      
    PRIMARY KEY (sku)                                        
)