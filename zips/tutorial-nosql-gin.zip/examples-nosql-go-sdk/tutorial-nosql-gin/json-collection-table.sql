CREATE TABLE if NOT EXISTS go_gin_albums(
   id String, PRIMARY KEY(id)
) AS JSON COLLECTION
;
