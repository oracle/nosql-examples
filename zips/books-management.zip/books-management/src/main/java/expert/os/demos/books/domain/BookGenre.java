package expert.os.demos.books.domain;

public enum BookGenre {
    ACTION,
    COMEDY,
    DRAMA,
    HORROR,
    SCIENCE_FICTION,
    FANTASY,
    ROMANCE,
    THRILLER,
    FICTION,
    DYSTOPIAN
}
